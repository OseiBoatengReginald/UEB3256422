import os

# Global list to hold expense records
expenses = []

# 1. Add New Expense
def add_expense():
    try:
        amount = float(input("Enter amount: GHC "))
        category = input("Enter category (e.g., Food, Transport): ").strip()
        description = input("Enter description: ").strip()
        expense = {"amount": amount, "category": category, "description": description}
        expenses.append(expense)
        print("Expense added successfully.\n")
    except ValueError:
        print("Invalid input. Amount must be a number.\n")

# 2. View All Expenses
def view_expenses():
    if not expenses:
        print("No expenses recorded.\n")
        return
    print("\nAll Expenses:")
    for i, expense in enumerate(expenses, start=1):
        print(f"{i}. GHC{expense['amount']} - {expense['category']} - {expense['description']}")
    print()

# 3. Show Expense Summary
def show_summary():
    if not expenses:
        print("No expenses to summarize.\n")
        return
    summary = {}
    for expense in expenses:
        category = expense["category"]
        summary[category] = summary.get(category, 0) + expense["amount"]

    print("\nExpense Summary by Category:")
    for category, total in summary.items():
        print(f"{category}: GHC{total:.2f}")
    print()

# 4. Save and Exit
def save_and_exit(filename="expenses.txt"):
    try:
        with open(filename, "w") as file:
            for expense in expenses:
                line = f"{expense['amount']},{expense['category']},{expense['description']}\n"
                file.write(line)
        print("Expenses saved. Goodbye!")
    except Exception as e:
        print(f"Error saving file: {e}")

# Load previous expenses from file (if exists)
def load_expenses(filename="expenses.txt"):
    if os.path.exists(filename):
        with open(filename, "r") as file:
            for line in file:
                try:
                    amount, category, description = line.strip().split(",", 2)
                    expenses.append({"amount": float(amount), "category": category, "description": description})
                except ValueError:
                    continue  # skip bad lines

# Menu-driven interface
def main():
    load_expenses()
    while True:
        print("=== Personal Expense Tracker ===")
        print("1. Add New Expense")
        print("2. View All Expenses")
        print("3. Show Expense Summary")
        print("4. Save and Exit")

        choice = input("Enter your choice (1-4): ").strip()
        if choice == '1':
            add_expense()
        elif choice == '2':
            view_expenses()
        elif choice == '3':
            show_summary()
        elif choice == '4':
            save_and_exit()
            break
        else:
            print("Invalid choice. Please try again.\n")

# Entry point
if __name__ == "__main__":
    main()
