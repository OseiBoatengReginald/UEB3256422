from scraper import fetch_headlines
from text_utils import clean_headlines

def main():
    try:
        headlines = fetch_headlines()
        cleaned = clean_headlines(headlines)
        
        print("Cleaned Headlines:")
        for i, h in enumerate(cleaned, 1):
            print(f"{i}. {h}")
    except Exception as e:
        print("An error occurred:", e)

if __name__ == "__main__":
    main()
