import string

def clean_headlines(headlines):
    cleaned = []
    seen = set()
    for headline in headlines:
        headline = headline.strip()
        headline = headline.translate(str.maketrans("", "", string.punctuation))
        headline = " ".join(headline.split())
        headline = headline.title()

        if headline not in seen:
            seen.add(headline)
            cleaned.append(headline)
    return cleaned
