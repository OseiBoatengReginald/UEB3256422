import requests
from bs4 import BeautifulSoup

def fetch_headlines():
    url = "https://www.theguardian.com/international"
    try:
        response = requests.get(url)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, "html.parser")
        headlines = []

        for item in soup.find_all("h3"):
            if item.text.strip():
                headlines.append(item.text.strip())

        if not headlines:
            raise ValueError("No headlines found.")
        return headlines

    except requests.exceptions.RequestException as e:
        raise ConnectionError("Network issue: " + str(e))
    except Exception as e:
        raise RuntimeError("Scraping error: " + str(e))
