# Projects 6, 7, and 8 - Submission Package

This package contains starter code and flowcharts for Project 6, Project 7, and guidance for Project 8 (Django).

## Files included
- `project6_flower.py` : Flower class, input and display methods.
- `project7_logger.py` : make_logger factory and sample decorated functions.
- `flowchart_project6.png` : Flowchart image for Project 6.
- `flowchart_project7.png` : Flowchart image for Project 7.
- `README.md` : This file with Django setup steps and GitHub push instructions.

---

## Project 8 - Quick Django Setup (commands)
Replace `yourusername` and `your-repo` with your GitHub username and repo name where needed.

```bash
mkdir my_django_project
cd my_django_project
python -m venv venv
# activate venv:
# on Windows:
# venv\Scripts\activate
# on Mac/Linux:
# source venv/bin/activate

python -m pip install --upgrade pip
python -m pip install Django

django-admin startproject mysite .
python manage.py startapp main

# Add 'main' to INSTALLED_APPS in mysite/settings.py
python manage.py migrate
python manage.py runserver
# open http://127.0.0.1:8000 to see the app
```

## Basic file snippets (copy into your project files)

### main/views.py
```python
from django.shortcuts import render

def home(request):
    return render(request, "home.html", {"message": "Hello from Django!"})
```

### main/urls.py
```python
from django.urls import path
from . import views

urlpatterns = [
    path("", views.home, name="home"),
]
```

### mysite/urls.py (include main.urls)
```python
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path("admin/", admin.site.urls),
    path("", include("main.urls")),
]
```

### templates/home.html
```html
<!doctype html>
<html>
<head><title>Home</title></head>
<body>
  <h1>{{ message }}</h1>
</body>
</html>
```

## GitHub push (example)
```bash
git init
git add .
git commit -m "Initial Django project"
# create repo on GitHub then:
git remote add origin https://github.com/yourusername/your-repo.git
git branch -M main
git push -u origin main
```

Good luck — paste the GitHub repo URL into your logbook before the deadline.