# project6_flower.py

class Flower:
    def __init__(self, price=0.0, color="", smell=""):
        self.price = price
        self.color = color
        self.smell = smell

    def get(self):
        try:
            self.price = float(input("Enter price: ₵"))
        except ValueError:
            print("Invalid price. Using 0.0")
            self.price = 0.0
        self.color = input("Enter color: ")
        self.smell = input("Enter smell: ")

    def display(self):
        print(f"Flower details -> Price: ₵{self.price:.2f}, Color: {self.color}, Smell: {self.smell}")

def main():
    lilly = Flower()
    rose = Flower()
    hibiscus = Flower()

    print("Enter details for Lilly:")
    lilly.get()
    print("\nEnter details for Rose:")
    rose.get()
    print("\nEnter details for Hibiscus:")
    hibiscus.get()

    print("\n--- Displaying flowers ---")
    print("Lilly:")
    lilly.display()
    print("Rose:")
    rose.display()
    print("Hibiscus:")
    hibiscus.display()

if __name__ == "__main__":
    main()
