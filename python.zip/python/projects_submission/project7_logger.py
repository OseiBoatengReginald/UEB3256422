# project7_logger.py
import functools

def make_logger(prefix):
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            print(f"{prefix} Entering {func.__name__}")
            result = func(*args, **kwargs)
            print(f"{prefix} Exiting {func.__name__}")
            return result
        return wrapper
    return decorator

math_logger = make_logger("[MathModule]")
network_logger = make_logger("[NetworkModule]")

@math_logger
def add(a, b):
    return a + b

@network_logger
def fetch_data(url):
    print(f"Fetching from {url}")
    return {"status": "ok"}

if __name__ == "__main__":
    print("add result:", add(3, 4))
    print("fetch result:", fetch_data("https://jsonplaceholder.typicode.com/posts/1"))
