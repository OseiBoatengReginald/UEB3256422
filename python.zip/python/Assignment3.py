# Contact dictionary: Key = name, Value = (phone_number, city)
contacts = {}
contact_ids = range(101, 106)  # Simulating contact IDs

# 1. Add a new contact
def add_contact(contact_dict, name, phone, city):
    if name in contact_dict:
        print("Contact already exists.\n")
    else:
        contact_dict[name] = (phone, city)
        print(f"Contact '{name}' added successfully.\n")

# 2. Sort contacts by name using lambda
def sort_contacts(contact_dict):
    return sorted(contact_dict.items(), key=lambda item: item[0])

# 3. Create a set of unique cities
def get_unique_cities(contact_dict):
    return set(city for _, city in contact_dict.values())

# 4. Search contacts by city
def search_by_city(contact_dict, search_city):
    found = {name: info for name, info in contact_dict.items() if info[1].lower() == search_city.lower()}
    if found:
        print(f"\nContacts in '{search_city}':")
        for name, (phone, city) in found.items():
            print(f"{name} - {phone} - {city}")
    else:
        print(f"No contacts found in '{search_city}'.")
    print()

# 5. Final summary
def print_summary(contact_dict):
    if not contact_dict:
        print("No contacts to summarize.\n")
        return

    total_contacts = len(contact_dict)
    unique_cities = get_unique_cities(contact_dict)
    longest_name = max(contact_dict.keys(), key=len)

    print("\n--- Contact Summary ---")
    print(f"Total contacts: {total_contacts}")
    print(f"Unique cities: {len(unique_cities)}")
    print(f"Contact with longest name: {longest_name}")
    print()

# Menu system
def main():
    print("Simulated Contact IDs: ", list(contact_ids))

    while True:
        print("=== Contact Management System ===")
        print("1. Add Contact")
        print("2. View Sorted Contacts")
        print("3. Search by City")
        print("4. Show Summary")
        print("5. Exit")

        choice = input("Choose an option (1-5): ").strip()

        if choice == '1':
            name = input("Enter name: ")
            phone = input("Enter phone number: ")
            city = input("Enter city: ")
            add_contact(contacts, name, phone, city)

        elif choice == '2':
            sorted_list = sort_contacts(contacts)
            print("\nSorted Contacts:")
            for name, (phone, city) in sorted_list:
                print(f"{name} - {phone} - {city}")
            print()

        elif choice == '3':
            city = input("Enter city to search: ")
            search_by_city(contacts, city)

        elif choice == '4':
            print_summary(contacts)

        elif choice == '5':
            print("Exiting program. Goodbye!")
            break

        else:
            print("Invalid option. Please try again.\n")

# Entry point
if __name__ == "__main__":
    main()
