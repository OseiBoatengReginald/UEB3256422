"""a = 10
b = 0
try:
    c = a/b
    print("Division by zero:",c)
except ZeroDivisionError:
    print("You cannot divide by zero")"""
    
    
"""a = 50
b = "10"

try:
    c = a+b
    print("Adding of two numbers",c)
except:
    print("You cannot add a string to a string to an integers")"""
    
"""#ValueError
a = "abc"
try:
    b = int(a)
    print("integer",b)
except ValueError:
    print("You cannot supply a suppl a string to an integer method")"""
    
"""#IndexError
a = [1,2,3]

try:
    print(a[5])
except IndexError:
    print("Accessing an index that does not exist")"""
    
filename = input("Enter the name of the field to read:")

try:
    with open(filename, "r") as file:
        print(file.read())
except FileExistsError:
    print(f"Error: '{filename}' does not exist")