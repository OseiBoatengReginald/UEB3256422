class Pet:
    def __init__(self, name, pet_type, age):
        self.name = name
        self.pet_type = pet_type
        self.age = age

    def display_info(self):
        print(f"Name: {self.name}")
        print(f"Type: {self.pet_type}")
        print(f"Age: {self.age} years\n")

    def update_age(self, new_age):
        self.age = new_age
        print(f"{self.name}'s age has been updated to {self.age} years.\n")


# Create pet objects
pet1 = Pet("Buddy", "Dog", 3)
pet2 = Pet("Mittens", "Cat", 2)

# Display original pet info
print("Original Pet Details:")
pet1.display_info()
pet2.display_info()

# Update age of one pet
pet1.update_age(4)

# Display updated info
print("Updated Pet Details:")
pet1.display_info()
pet2.display_info()
